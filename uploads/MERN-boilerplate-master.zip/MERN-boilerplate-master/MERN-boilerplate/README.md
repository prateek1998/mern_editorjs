# MERN-boilerplate

- Start dev (running dev server (nodemon) and the client)
  `npm run dev`

- Start dev server (nodemon)
  `npm run server`

- Start server.js
  `npm run start`

- Start the client
  `npm run client`

Server: http://localhost:5000
Client: http://localhost:3000
